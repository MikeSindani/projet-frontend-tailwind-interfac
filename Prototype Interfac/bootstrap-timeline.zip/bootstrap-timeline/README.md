# Bootstrap Timeline

A Pen created on CodePen.io. Original URL: [https://codepen.io/jasondavis/pen/nXLJbg](https://codepen.io/jasondavis/pen/nXLJbg).

Bootstrap Timeline